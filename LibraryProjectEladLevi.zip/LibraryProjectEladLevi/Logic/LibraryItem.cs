﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.Xaml.Controls;

namespace Logic
{
    [Serializable]
    public abstract class LibraryItem
    {
        public string Title { set; get; }
        public Genre Genre { set; get; }
        public string Description { set; get; }
        public DateTime DateTimeCreated { set; get; }
        public string DateTimeCreatedString { get { return $"{DateTimeCreated:d}"; } }
        public double Discount { set; get; }
        public DateTime FinalDiscount { set; get; }
        public double OriginalPrice { set; get; }
        public double Price { set; get; }
        public string Company { set; get; }
        public IsRented IsRented { set; get; }
        public DateTime StartingRentTime { set; get; }
        public string StartingRentTimeString { get { return $"{StartingRentTime:d}"; } }
        public DateTime FinalRentTime { set; get; }
        public string FinalRentTimeString { get { return $"{FinalRentTime:d}"; } }
        public int DaysLeft { get { return (FinalRentTime - StartingRentTime).Days; } }
        public Guid Guid { protected set; get; }
        public abstract string Search();
        public LibraryItem(string title, double price, string description, string company, Genre genre, DateTime dateTimeCreated)
        {
            Guid = Guid.NewGuid();
            Title = title;
            Price = price;
            Description = description;
            Company = company;
            Genre= genre;
            DateTimeCreated = dateTimeCreated;
            IsRented = IsRented.No;
            Discount = 0;
            OriginalPrice = price;
        }
    }
    [Serializable]
    public class Book : LibraryItem, IAuthor
    {
        public Book(string title, double price, string author, string description, string company, Genre genre, DateTime dateTimeCreated) : base(title, price, description, company, genre, dateTimeCreated)
        {
            Author = author;
        }
        public string Author { get; set; }
        public override string ToString()
        {
            return $"Title: {Title}\n" +
                $"Price: {Price}\n" +
                $"Author: {Author}\n" +
                $"Description: {Description}\n" +
                $"Company: {Company}\n" +
                $"Genre: {Genre}\n" +
                $"Date Time Created {DateTimeCreated:D}";
        }
        public override string Search()
        {
            return $"{Title} {Author} {Price} {Company} {Genre} {DateTimeCreated}";
        }
    }
    [Serializable]
    public class Journal : LibraryItem
    {
        public Journal(string title, double price, string description, string company, Genre genre, DateTime dateTimeCreated) : base(title, price, description, company, genre, dateTimeCreated) { }
        public override string ToString()
        {
            return $"Title: {Title}\n" +
                $"Price: {Price}\n" +
                $"Description: {Description}\n" +
                $"Company: {Company}\n" +
                $"Genre: {Genre}\n" +
                $"Date Time Created {DateTimeCreated:D}";
        }
        public override string Search()
        {
            return $"{Title} {Price} {Company} {Genre} {DateTimeCreated}";
        }
    }
    public interface IAuthor
    {
        string Author { get; set; }
    }
    [Flags]
    public enum Genre { Fantasy = 1, Adventure = 2, Horror = 4, Comedy = 8, History = 16, Mystery = 32, Romance = 64, ScienceFiction = 128, Thriller = 256 }
    public enum IsRented { Yes = 1, No = 2 }
}