﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logic
{
    public abstract class ItemComparisons
    {
        public class CompareByTitle : IComparer<LibraryItem>
        {
            public int Compare(LibraryItem x, LibraryItem y)
            {
                return x.Title.CompareTo(y.Title);
            }
        }
        public class CompareByAuthor : IComparer<Book>
        {
            public int Compare(Book x, Book y)
            {
                return x.Author.CompareTo(y.Author);
            }
        }
        public class CompareByPrice : IComparer<LibraryItem>
        {
            public int Compare(LibraryItem x, LibraryItem y)
            {
                return x.Price.CompareTo(y.Price);
            }
        }
        public class CompareByCompany : IComparer<LibraryItem>
        {
            public int Compare(LibraryItem x, LibraryItem y)
            {
                return x.Company.CompareTo(y.Company);
            }
        }
        public class CompareByGenre : IComparer<LibraryItem>
        {
            public int Compare(LibraryItem x, LibraryItem y)
            {
                return x.Genre.CompareTo(y.Genre);
            }
        }
        public class CompareByDate : IComparer<LibraryItem>
        {
            public int Compare(LibraryItem x, LibraryItem y)
            {
                return x.DateTimeCreated.CompareTo(y.DateTimeCreated);
            }
        }
    }
}
