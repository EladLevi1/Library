﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logic
{
    internal class User
    {

    }

    internal class Manager : User
    {

    }

    internal class Customer : User
    {

    }
}
