﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json.Utilities;
using System.Runtime.Serialization.Formatters.Binary;
using Windows.Storage;
using System.Collections;
using System.ServiceModel.Channels;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Documents;
using System.Threading;
using System.Linq.Expressions;
using System.Diagnostics;

namespace Logic
{
    public class Library
    {
        private Dictionary<Guid, LibraryItem> dic = new Dictionary<Guid, LibraryItem>();
        public Library()
        {
            Load();
        }
        private void FirstCreatingItems()
        {
            Book book1 = new Book("The Hunger Games", 14.99, "Suzanne Collins",
                "In the ruins of a place once known as North America lies the nation of Panem, a shining Capitol surrounded by twelve outlying districts. The Capitol is harsh and cruel and keeps the districts in line by forcing them all to send one boy and one girl between the ages of twelve and eighteen to participate in the annual Hunger Games, a fight to the death on live TV. Sixteen-year-old Katniss Everdeen, who lives alone with her mother and younger sister, regards it as a death sentence when she steps forward to take her sister's place in the Games. But Katniss has been close to dead before—and survival, for her, is second nature. Without really meaning to, she becomes a contender. But if she is to win, she will have to start making choices that weight survival against humanity and life against love.",
                "Scholastic", Genre.Fantasy | Genre.Adventure | Genre.Romance | Genre.ScienceFiction, new DateTime(2008, 09, 14));
            Book book2 = new Book("The Chronicles of Narnia", 19.99, "Clive Staples Lewis",
                "Four kids travel through a wardrobe to the land of Narnia and learn of their destiny to free it with the guidance of a mystical lion. Four siblings are sent away from home during the blitz of WWII. They are sent to be watched over by an old Professor Kirke, who owns a massive mansion.",
                "Geoffrey Bles", Genre.Fantasy | Genre.Adventure | Genre.ScienceFiction, new DateTime(1950, 10, 16));
            Book book3 = new Book("Harry Potter", 10.99, "Joanne Rowling",
                "On his 11th birthday, Harry receives a letter inviting him to study magic at the Hogwarts School of Witchcraft and Wizardry. Harry discovers that not only is he a wizard, but he is a famous one. He meets two best friends, Ron Weasley and Hermione Granger, and makes his first enemy, Draco Malfoy.",
                "Bloomsbury", Genre.Fantasy | Genre.Adventure | Genre.ScienceFiction, new DateTime(1997, 06, 30));
            Book book4 = new Book("The Giving Tree", 9.5, "Shel Silverstein",
                "Every day the boy would come to the tree to eat her apples, swing from her branches, or slide down her trunk...and the tree was happy. But as the boy grew older he began to want more from the tree, and the tree gave and gave and gave.",
                "Harper & Row", Genre.Fantasy, new DateTime(1964, 01, 01));
            Book book5 = new Book("Alice's Adventures in Wonderland", 19.99, "Lewis Carroll",
                "When Alice sees a white rabbit take a watch out of its waistcoat pocket she decides to follow it, and a sequence of most unusual events is set in motion. This mini book contains the entire topsy-turvy stories of Alice's Adventures in Wonderland and Through the Looking-Glass, accompanied by practical notes and Martina Pelouso's memorable full-colour illustrations.",
                "Macmillan", Genre.Fantasy | Genre.Adventure, new DateTime(1871, 12, 27));
            Journal journal1 = new Journal("The Princess Diaries", 9.90,
                "Mia Thermopolis is pretty sure there's nothing worse than being a five-foot-nine, flat-chested freshman, who also happens to be flunking Algebra. Is she ever in for a surprise. First mom announces that she's dating Mia's Algebra teacher. Then Dad has to go and reveal that he is the crown prince of Genovia. And guess who still doesn't have a date for the Cultural Diversity Dance?",
                "Turtleback", Genre.Romance | Genre.Comedy, new DateTime(2000, 09, 19));
            Journal journal2 = new Journal("Dracula", 8.99,
                "When Jonathan Harker visits Transylvania to help Count Dracula with the purchase of a London house, he makes a series of horrific discoveries about his client. Soon afterwards, various bizarre incidents unfold in England: an apparently unmanned ship is wrecked off the coast of Whitby; a young woman discovers strange puncture marks on her neck; and the inmate of a lunatic asylum raves about the 'Master' and his imminent arrival.",
                "Norton", Genre.Horror | Genre.Fantasy, new DateTime(1897, 05, 26));
            Journal journal3 = new Journal("Anne Frank Diary", 19.90,
                "In 1942, with the Nazis occupying Holland, a thirteen-year-old Jewish girl and her family fled their home in Amsterdam and went into hiding. For the next two years, until their whereabouts were betrayed to the Gestapo, the Franks and another family lived cloistered in the “Secret Annexe” of an old office building. Cut off from the outside world, they faced hunger, boredom, the constant cruelties of living in confined quarters, and the ever-present threat of discovery and death. In her diary Anne Frank recorded vivid impressions of her experiences during this period. By turns thoughtful, moving, and surprisingly humorous, her account offers a fascinating commentary on human courage and frailty and a compelling self-portrait of a sensitive and spirited young woman whose promise was tragically cut short.",
                "Bantam", Genre.Horror | Genre.Thriller, new DateTime(1947, 06, 25));
            Journal journal4 = new Journal("The Jolly Christmas Postman", 5.99,
                "The Jolly Postman brings a batch of wonderful letters for Christmas, including notes from the Big Bad Wolf and all the King's men.",
                "Little Brown", Genre.Fantasy | Genre.Comedy, new DateTime(1991, 01, 01));
            Journal journal5 = new Journal("Diary of a Spider", 8.5,
                "This is the diary... of a spider. But don't be worried – he's more scared of you and your gigantic shoe! Actually, he's a lot like you. He goes to gym class and has Grandparents' Day at school. But he also spins sticky webs, scales walls, and takes wind–catching lessons. Lucky for him, his best friend is a fly!",
                "HarperCollins", Genre.Fantasy | Genre.Comedy | Genre.Adventure, new DateTime(1996, 01, 01));
            dic.Add(book1.Guid, book1);
            dic.Add(book2.Guid, book2);
            dic.Add(book3.Guid, book3);
            dic.Add(book4.Guid, book4);
            dic.Add(book5.Guid, book5);
            dic.Add(journal1.Guid, journal1);
            dic.Add(journal2.Guid, journal2);
            dic.Add(journal3.Guid, journal3);
            dic.Add(journal4.Guid, journal4);
            dic.Add(journal5.Guid, journal5);
        }
        private async void Load()
        {
            BinaryFormatter bf = new BinaryFormatter();
            StorageFolder localFolder = ApplicationData.Current.LocalFolder;
            try
            {
                StorageFile file = await localFolder.GetFileAsync("ItemsDictionary.dat");
                using (Stream stream = await file.OpenStreamForReadAsync())
                {
                    dic = (Dictionary<Guid, LibraryItem>)bf.Deserialize(stream);
                    CheckIfDiscountIsOver();
                    stream.Close();
                }
            }
            catch (FileNotFoundException ex)
            {
                FirstCreatingItems();
                Save();
            }
            catch (Exception)
            {
                FirstCreatingItems();
                Save();
            }
        }
        public async void Save()
        {
            BinaryFormatter bf = new BinaryFormatter();
            StorageFolder localFolder = ApplicationData.Current.LocalFolder;
            try
            {
                StorageFile file = await localFolder.CreateFileAsync("ItemsDictionary.dat", CreationCollisionOption.ReplaceExisting);
                using (Stream stream = await file.OpenStreamForWriteAsync())
                {
                    bf.Serialize(stream, dic);
                    stream.Close();
                }
            }
            catch (Exception) { }
        }
        public void CheckIfDiscountIsOver()
        {
            int counter = 0;
            foreach (var item in dic.Values)
            {
                if (item.Discount > 0 && item.IsRented == IsRented.No)
                {
                    if (DateTime.Today.Date == item.FinalDiscount.Date)
                    {
                        item.Price = item.OriginalPrice;
                        item.Discount = 0;
                        counter++;
                    }
                }
            }
            if (counter > 0)
                Save();
        }
        public void Sort(IComparer<LibraryItem> criteria)
        {
            List<LibraryItem> items = new List<LibraryItem>();
            foreach (var item in dic)
            {
                items.Add(item.Value);
            }
            items.Sort(criteria);
            dic.Clear();
            foreach (var item in items)
            {
                dic.Add(item.Guid, item);
            }
        }
        public void SortAuthor(IComparer<Book> criteria)
        {
            List<Book> items = new List<Book>();
            List<Journal> itemsJ = new List<Journal>();
            foreach (var item in dic)
            {
                if (item.Value.GetType() == typeof(Book))
                    items.Add((Book)item.Value);
                if (item.Value.GetType() == typeof(Journal))
                    itemsJ.Add((Journal)item.Value);
            }
            items.Sort(criteria);
            dic.Clear();
            foreach (var item in items)
            {
                dic.Add(item.Guid, item);
            }
            foreach (var item in itemsJ)
            {
                dic.Add(item.Guid, item);
            }
        }
        public Dictionary<Guid, LibraryItem> GetDic { get { return dic; } }
        public void AddItem(LibraryItem item)
        {
            dic.Add(item.Guid, item);
            Save();
        }
        public void RemoveItem(Guid id)
        {
            if (CheckIfGuidIsAlreadyExist(id))
            {
                dic.Remove(id);
                Save();
            }
        }
        public void RentItem(Guid id)
        {
            if (CheckIfGuidIsAlreadyExist(id))
            {
                dic[id].IsRented = IsRented.Yes;
                dic[id].StartingRentTime = DateTime.Now;
                dic[id].FinalRentTime= DateTime.Now.AddDays(14);
                Save();
            }
        }
        public void ReturnItem(Guid id)
        {
            if (CheckIfGuidIsAlreadyExist(id))
            {
                dic[id].IsRented = IsRented.No;
                dic[id].StartingRentTime = DateTime.MinValue;
                dic[id].FinalRentTime = DateTime.MaxValue;
                Save();
            }
        }
        public string ItemDetails(Guid id)
        {
            if (CheckIfGuidIsAlreadyExist(id))
                return dic[id].ToString();
            else
                return "";
        }
        public void EditItemTitle(Guid id, string title)
        {
            if (CheckIfGuidIsAlreadyExist(id))
            {
                dic[id].Title = CheckIfTitleValid(title);
                Save();
            }
        }
        public void EditItemGenre(Guid id, Genre genre)
        {
            if (CheckIfGuidIsAlreadyExist(id))
            {
                dic[id].Genre = CheckIfGenreIsValid(genre);
                Save();
            }
        }
        public void EditItemDescription(Guid id, string description)
        {
            if (CheckIfGuidIsAlreadyExist(id))
            {
                dic[id].Description = CheckIfDescriptionIsValid(description);
                Save();
            }
        }
        public void EditItemPrice(Guid id, string price)
        {
            if (CheckIfGuidIsAlreadyExist(id))
            {
                dic[id].Price = CheckIfPriceIsValid(price);
                Save();
            }
        }
        public void EditItemCompany(Guid id, string company)
        {
            if (CheckIfGuidIsAlreadyExist(id))
            {
                dic[id].Company = CheckIfCompanyIsValid(company);
                Save();
            }
        }
        public void EditItemAuthor(Guid id, string author)
        {
            if (CheckIfGuidIsAlreadyExist(id))
                if (dic[id] is IAuthor)
                {
                    Book book = (Book)dic[id];
                    book.Author = CheckIfAuthorIsValid(author);
                    dic[id] = book;
                    Save();
                }
        }
        public void EditItemDateTimeCreated(Guid id, DateTime created)
        {
            if (CheckIfGuidIsAlreadyExist(id))
            {
                dic[id].DateTimeCreated = CheckIfDateTimeCreatedIsValid(created);
                Save();
            }
        }
        public Dictionary<Guid, LibraryItem> SearchByPar(string contains)
        {
            Dictionary<Guid, LibraryItem> tempDic = new Dictionary<Guid, LibraryItem>();
            foreach (var item in dic.Values)
            {
                if (item.Search().ToLower().Contains(contains.ToLower()))
                {
                    tempDic.Add(item.Guid, item);
                }
            }
            return tempDic;
        }
        public bool CheckIfGuidIsAlreadyExist(Guid id)
        {
            if (dic.ContainsKey(id))
                return true;
            throw new InvalidOperationException("The library doesn't have what you are looking for!");
        }
        public string CheckIfTitleValid(string title)
        {
            if (title.Length > 2 && title.Length < 35)
            {
                if (title.Contains(' '))
                {
                    string[] words = title.Split(' ');
                    for (int i = 0; i < words.Length; i++)
                    {
                        words[i] = words[i][0].ToString().ToUpper() + words[i].Substring(1, words[i].Length - 1).ToLower();
                    }
                    string output = string.Join(" ", words);
                    return output;
                }
                else
                {
                    return title[0].ToString().ToUpper() + title.Substring(1, title.Length - 1).ToLower();
                }
            }
            throw new InvalidInputException("Invalid title!");
        }
        public string CheckIfCompanyIsValid(string company)
        {
            if (company.Length > 2 && company.Length < 30)
            {
                if (company.Contains(' '))
                {
                    string[] words = company.Split(' ');
                    for (int i = 0; i < words.Length; i++)
                    {
                        words[i] = words[i][0].ToString().ToUpper() + words[i].Substring(1, words[i].Length - 1).ToLower();
                    }
                    string output = string.Join(" ", words);
                    return output;
                }
                else
                {
                    return company[0].ToString().ToUpper() + company.Substring(1, company.Length - 1).ToLower();
                }
            }
            throw new InvalidInputException("Invalid company!");
        }
        public double CheckIfPriceIsValid(string price)
        {
            if (double.TryParse(price, out double priceD) && priceD > 0 && priceD < 100)
                return priceD;
            throw new InvalidInputException("Invalid price!");
        }
        public string CheckIfAuthorIsValid(string author)
        {
            if (author.Length > 2 && author.Length < 25)
            {
                if (author.Contains(' '))
                {
                    string[] words = author.Split(' ');
                    for (int i = 0; i < words.Length; i++)
                    {
                        words[i] = words[i][0].ToString().ToUpper() + words[i].Substring(1, words[i].Length - 1).ToLower();
                    }
                    string output = string.Join(" ", words);
                    return output;
                }
                else
                {
                    return author[0].ToString().ToUpper() + author.Substring(1, author.Length - 1).ToLower();
                }
            }
            throw new InvalidInputException("Invalid author!");
        }
        public string CheckIfDescriptionIsValid(string description)
        {
            if (description.Length > 2)
                return description;
            throw new InvalidInputException("Invalid description");
        }
        public double CheckIfDiscountIsValid(string discount)
        {
            if (double.TryParse(discount, out double dis) && dis > 0 && dis < 80)
                return dis;
            throw new InvalidInputException("Invalid discount!");
        }
        public DateTime CheckIfDiscountFinalDateIsValid(DateTime date)
        {
            if (date.Date > DateTime.Today)
                return date;
            throw new InvalidInputException("Invalid date");
        }
        public Genre CheckIfGenreIsValid(Genre genre)
        {
            if (genre > 0)
                return genre;
            throw new InvalidInputException("Invalid genre");
        }
        public DateTime CheckIfDateTimeCreatedIsValid(DateTime created)
        {
            if (created < DateTime.Today)
                return created;
            throw new InvalidInputException("Invalid date");
        }
    }
    public class InvalidInputException : Exception
    {
        public InvalidInputException(string msg) : base(msg) { }
        public override string Message => "Invalid Input " + base.Message;
    }
}