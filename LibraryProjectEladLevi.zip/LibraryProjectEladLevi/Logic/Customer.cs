﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Xml.Linq;
using Windows.ApplicationModel.VoiceCommands;
using Windows.Storage;

namespace Logic
{
    [Serializable]
    public class Customer
    {
        private Dictionary<Guid, LibraryItem> rentedItems = new Dictionary<Guid, LibraryItem>();
        private List<Message> messages = new List<Message>();
        public string UserName { get; set; }
        public string Password { get; set; }
        public Customer(string username, string password)
        {
            UserName = username;
            Password = password;
        }
        public Dictionary<Guid, LibraryItem> GetRentedItems { get { return rentedItems; } }
        public List<Message> GetMessages { get { return messages; }}
        public void RecieveNewMessage(Message msg)
        {
            messages.Add(msg);
        }
        public void DeleteMessage(Message msg)
        {
            messages.Remove(msg);
        }
        public void RentItem(Guid id, LibraryItem item)
        {
            rentedItems.Add(id, item);
        }
        public void ReturnItem(Guid id)
        {
            rentedItems.Remove(id);
        }
        public override string ToString()
        {
            if (rentedItems.Count > 0)
            {
                string items = "";
                foreach (var item in rentedItems.Values)
                {
                    items += $"Title: {item.Title}\n" +
                        $"Rent Date: {item.StartingRentTimeString}\n" +
                        $"Final Rent Date: {item.FinalRentTimeString} \n" +
                        $"Days to return: {(item.FinalRentTime - item.StartingRentTime).Days}\n\n";
                }
                return $"Username: {UserName}\n\n" +
                    $"Rented Items: {rentedItems.Count}\n\n" +
                    $"{items}";
            }
            else
            {
                return $"Username: {UserName}\n\n" +
                    $"Rented Items: 0";
            }
        }
    }

    [Serializable]
    public class ManageCustomers
    {
        private List<Customer> customers = new List<Customer>();
        public ManageCustomers()
        {
            Load();
        }
        private void FirstCreatingUsers()
        {
            Customer Elad = new Customer("Elad", "11111");
            Customer Yuval = new Customer("Yuval", "22222");
            Customer Ron = new Customer("Ron", "33333");
            Customer Tal = new Customer("Tal", "44444");
            Customer Ori = new Customer("Ori", "55555");
            customers.Add(Elad);
            customers.Add(Yuval);
            customers.Add(Ron);
            customers.Add(Tal);
            customers.Add(Ori);
            Save();
        }
        private async void Load()
        {
            BinaryFormatter bf = new BinaryFormatter();
            StorageFolder localFolder = ApplicationData.Current.LocalFolder;
            try
            {
                StorageFile file = await localFolder.GetFileAsync("CustomersList.dat");
                using (Stream stream = await file.OpenStreamForReadAsync())
                {
                    customers = (List<Customer>)bf.Deserialize(stream);
                    stream.Close();
                }
            }
            catch (FileNotFoundException ex)
            {
                FirstCreatingUsers();
            }
            catch (Exception)
            {
                FirstCreatingUsers();
            }
        }
        private async void Save()
        {
            BinaryFormatter bf = new BinaryFormatter();
            StorageFolder localFolder = ApplicationData.Current.LocalFolder;
            StorageFile file = await localFolder.CreateFileAsync("CustomersList.dat", CreationCollisionOption.ReplaceExisting);
            try
            {
                using (Stream stream = await file.OpenStreamForWriteAsync())
                {
                    bf.Serialize(stream, customers);
                    stream.Close();
                }
            }
            catch (Exception) { }
        }
        public List<string> GetUserNames
        {
            get
            {
                List<string> names = new List<string>();
                foreach (var cust in customers)
                {
                    names.Add(cust.UserName);
                }
                return names;
            }
        }
        public List<Customer> GetCustomers { get { return customers; } }
        public void RentItem(Guid id, LibraryItem item, Customer cust)
        {
            if (GetUserNames.Contains(cust.UserName))
            {
                cust.RentItem(id, item);
                Message msg = new Message();
                msg.Title = $"{item.GetType().Name} - Order Reciept";
                msg.Body = $"Enjoy your new {item.GetType().Name}, {item.Title} for a time limit of 14 days.\n" +
                    $"Date of starting rent: {item.StartingRentTime:d},\n" +
                    $"Date of ending rent: {item.FinalRentTime:d}.";
                SendMessage(cust, msg);
                Save();
            }
        }
        public void ReturnItem(Guid id, LibraryItem item, Customer cust)
        {
            if (GetUserNames.Contains(cust.UserName))
            {
                if (!cust.GetRentedItems.ContainsKey(id))
                    throw new InvalidOperationException("The item is not rented by the specific user");
                cust.ReturnItem(id);
                Message msg = new Message();
                msg.Title = $"{item.GetType().Name} - Return Reciept";
                msg.Body = $"You successfully returned your {item.GetType().Name}, {item.Title}.";
                SendMessage(cust, msg);
                Save();
            }
        }
        public Customer Login(string username, string password)
        {
            string name = UsernameValidation(username);
            string pass = PasswordValidation(password);
            foreach (var cust in customers)
            {
                if (cust.UserName == name)
                {
                    if (cust.Password == pass)
                    {
                        return cust;
                    }
                    else
                    {
                        throw new InvalidInputException($"Password is not correct!");
                    }
                }
            }
            throw new InvalidInputException($"Username {name} not found!");
        }
        public Customer Register(string username, string password)
        {
            string name = UsernameValidation(username);
            string pass = PasswordValidation(password);
            if (!GetUserNames.Contains(name))
            {
                Customer cust = new Customer(name, pass);
                customers.Add(cust);
                Save();
                return cust;
            }
            throw new InvalidInputException($"Username {name} is already taken!");
        }
        public void RemoveCustomer(Customer cust)
        {
            if (cust.GetRentedItems.Count == 0)
            {
                customers.Remove(cust);
                Save();
            }
            else
                throw new InvalidOperationException("You can't remove a customer that has rented items!");
        }
        public void ChangeUsername(Customer cust, string username)
        {
            if (customers.Contains(cust))
            {
                if (!GetUserNames.Contains(username))
                {
                    cust.UserName = UsernameValidation(username);
                }
                else
                {
                    throw new InvalidInputException($"Username: {username} is already in use!");
                }
            }
            else
            {
                throw new InvalidInputException("The user is not valid!");
            }
            Save();
        }
        public void ChangePassword(Customer cust, string password)
        {
            if (customers.Contains(cust))
            {
                cust.Password = PasswordValidation(password);
            }
            else
            {
                throw new InvalidInputException("The user is not valid!");
            }
            Save();
        }
        public void SendMessage(Customer cust, Message message)
        {
            if (customers.Contains(cust))
            {
                cust.RecieveNewMessage(message);
                Save();
            }
            else
                throw new InvalidOperationException("User in not found!");
        }
        public void RemoveMessage(Customer cust, Message message)
        {
            if (customers.Contains(cust))
            {
                cust.DeleteMessage(message);
                Save();
            }
            else
                throw new InvalidOperationException("User in not found!");
        }
        private string UsernameValidation(string username)
        {
            if (username.Length < 3 || username.Length > 10)
            {
                throw new InvalidInputException("Username letters must be between 3-10 alphabet letters!");
            }
            if (!Regex.IsMatch(username, @"^[a-zA-Z]+$"))
            {
                throw new InvalidInputException("Username only gets alphabet letters!");
            }
            if (username.Contains(" "))
            {
                throw new InvalidInputException("Username cannot contain a space!");
            }
            return username;
        }
        private string PasswordValidation(string password)
        {
            if (password.Length != 5)
            {
                throw new InvalidInputException("Password must be with 5 letters!");
            }
            if (Regex.IsMatch(password, @"^[a-zA-Z]+$"))
            {
                throw new InvalidInputException("Password only gets numbers!");
            }
            if (password.Contains(" "))
            {
                throw new InvalidInputException("Password cannot contain a space!");
            }
            return password;
        }
    }

    [Serializable]
    public class Message
    {
        public string Title { get; set; }
        public string Body { get; set; }
    }
}
