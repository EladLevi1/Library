﻿using Logic;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace LibraryProjectEladLevi
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class JournalsListPage : Page
    {
        private Mode mode;
        private Library library;
        public JournalsListPage()
        {
            this.InitializeComponent();
        }
        private void ShowList()
        {
            if (library != null)
            {
                foreach (var item in library.GetDic.Values)
                {
                    if (item.GetType() == typeof(Journal))
                    {
                        if (mode == Mode.Manager)
                        {
                            listView.Items.Add(item);
                        }
                        if (mode == Mode.Customer)
                        {
                            if (item.IsRented == IsRented.No)
                            {
                                listView.Items.Add(item);
                            }
                        }
                    }
                }
            }
        }
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            base.OnNavigatedTo(e);
            var param = e.Parameter as ParamToPass;
            if (param != null)
            {
                mode = param.Mode;
                library = param.Library;
            }
            rbtnTitle.IsChecked = true;
        }
        public ListView ListViewJournals { get { return listView; } set { listView.Items.Add(value); } }
        private void rbtnTitle_Checked(object sender, RoutedEventArgs e)
        {
            listView.Items.Clear();
            ItemComparisons.CompareByTitle compare = new ItemComparisons.CompareByTitle();
            library.Sort(compare);
            ShowList();
        }

        private void rbtnPrice_Checked(object sender, RoutedEventArgs e)
        {
            listView.Items.Clear();
            ItemComparisons.CompareByPrice compare = new ItemComparisons.CompareByPrice();
            library.Sort(compare);
            ShowList();
        }

        private void rbtnCompany_Checked(object sender, RoutedEventArgs e)
        {
            listView.Items.Clear();
            ItemComparisons.CompareByCompany compare = new ItemComparisons.CompareByCompany();
            library.Sort(compare);
            ShowList();
        }

        private void rbtnGenre_Checked(object sender, RoutedEventArgs e)
        {
            listView.Items.Clear();
            ItemComparisons.CompareByGenre compare = new ItemComparisons.CompareByGenre();
            library.Sort(compare);
            ShowList();
        }

        private void rbtnDate_Checked(object sender, RoutedEventArgs e)
        {
            listView.Items.Clear();
            ItemComparisons.CompareByDate compare = new ItemComparisons.CompareByDate();
            library.Sort(compare);
            ShowList();
        }
        private void txtBoxSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            listView.Items.Clear();
            string searchText = txtBoxSearch.Text;
            if (searchText == "")
            {
                ShowList();
                return;
            }
            Dictionary<Guid, LibraryItem> tempDic = library.SearchByPar(searchText);
            foreach (var item in tempDic.Values)
            {
                if (item.GetType() == typeof(Journal))
                    listView.Items.Add(item);
            }
        }
    }
}
