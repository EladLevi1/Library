﻿using Logic;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.ServiceModel.Channels;
using System.Threading.Tasks;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Popups;
using Windows.UI.ViewManagement;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace LibraryProjectEladLevi
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class CustomerPage : Page
    {
        private Library library;
        private Customer customer;
        private ManageCustomers mngc;
        public CustomerPage()
        {
            this.InitializeComponent();
        }
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            base.OnNavigatedTo(e);
            var param = e.Parameter as ParamToPass;
            if (param != null)
            {
                customer = param.Customer;
                library = param.Library;
                mngc = param.ManageCustomers;
            }
            txtBoxUsername.Text = customer.UserName;
            txtBoxPassword.Text = customer.Password;
            rbtnBooks.IsChecked = true;
            rbtnRentedItems.IsChecked = true;
        }
        private void rbtnBooks_Checked(object sender, RoutedEventArgs e)
        {
            var paramss = new ParamToPass { Mode = Mode.Customer, Library = library };
            frameLists.Navigate(typeof(BooksListPage), paramss);
        }
        private void rbtnJournal_Checked(object sender, RoutedEventArgs e)
        {
            var paramss = new ParamToPass { Mode = Mode.Customer, Library = library };
            frameLists.Navigate(typeof(JournalsListPage), paramss);
        }
        private void RefreshAll()
        {
            if (rbtnBooks.IsChecked == true)
            {
                rbtnBooks.IsChecked = false;
                rbtnBooks.IsChecked = true;
            }
            if (rbtnJournal.IsChecked == true)
            {
                rbtnJournal.IsChecked = false;
                rbtnJournal.IsChecked = true;
            }
            if (rbtnRentedItems.IsChecked == true)
            {
                rbtnRentedItems.IsChecked = false;
                rbtnRentedItems.IsChecked = true;
            }
            if (rbtnInbox.IsChecked == true)
            {
                rbtnInbox.IsChecked = false;
                rbtnRentedItems.IsChecked = true;
            }
        }
        private async void btnReturn_Click(object sender, RoutedEventArgs e)
        {
            var selectedItem = (LibraryItem)listViewRentedItems.SelectedItem;
            if (selectedItem != null)
            {
                MessageDialog messageDialog = new MessageDialog("Sure you want to return the item?");
                messageDialog.Commands.Add(new UICommand("Yes", (command) =>
                {
                    library.ReturnItem(selectedItem.Guid);
                    mngc.ReturnItem(selectedItem.Guid, selectedItem, customer);
                    RefreshAll();
                }));
                messageDialog.Commands.Add(new UICommand("No"));
                await messageDialog.ShowAsync();
            }
            else
            {
                _ = new MessageDialog("You need to select an item from your rented items list!").ShowAsync();
            }
        }
        private async void btnRent_Click(object sender, RoutedEventArgs e)
        {
            if (rbtnBooks.IsChecked == true)
            {
                BooksListPage booksListPage = (BooksListPage)frameLists.Content;
                Book selectedItem = (Book)booksListPage.ListViewBooks.SelectedItem;
                if (selectedItem != null)
                {
                    MessageDialog messageDialog = new MessageDialog("Sure you want to rent this item?");
                    messageDialog.Commands.Add(new UICommand("Yes", (command) =>
                    {
                        library.RentItem(selectedItem.Guid);
                        mngc.RentItem(selectedItem.Guid, selectedItem, customer);
                        RefreshAll();
                    }));
                    messageDialog.Commands.Add(new UICommand("No"));
                    await messageDialog.ShowAsync();
                }
                else
                {
                    _ = new MessageDialog("You need to select an item from the list!").ShowAsync();
                }
            }
            if (rbtnJournal.IsChecked == true)
            {
                JournalsListPage journalsListPage = (JournalsListPage)frameLists.Content;
                Journal selectedItem = (Journal)journalsListPage.ListViewJournals.SelectedItem;
                if (selectedItem != null)
                {
                    MessageDialog messageDialog = new MessageDialog("Sure you want to rent this item?");
                    messageDialog.Commands.Add(new UICommand("Yes", (command) =>
                    {
                        library.RentItem(selectedItem.Guid);
                        customer.RentItem(selectedItem.Guid, selectedItem);
                        RefreshAll();
                    }));
                    messageDialog.Commands.Add(new UICommand("No"));
                    await messageDialog.ShowAsync();
                }
                else
                {
                    _ = new MessageDialog("You need to select an item from the list!").ShowAsync();
                }
            }
        }
        private void btnBackToMain_Click(object sender, RoutedEventArgs e)
        {
            var paramss = new ParamToPass { ManageCustomers = mngc, Library = library };
            Frame.Navigate(typeof(MainPage), paramss);
        }
        private void btnItemInfo_Click(object sender, RoutedEventArgs e)
        {
            if (rbtnBooks.IsChecked == true)
            {
                BooksListPage booksListPage = (BooksListPage)frameLists.Content;
                Book selectedItem = (Book)booksListPage.ListViewBooks.SelectedItem;
                if (selectedItem != null)
                {
                    _ = new MessageDialog(library.ItemDetails(selectedItem.Guid)).ShowAsync();
                    return;
                }
            }
            if (rbtnJournal.IsChecked == true)
            {
                JournalsListPage journalsListPage = (JournalsListPage)frameLists.Content;
                Journal selectedItem = (Journal)journalsListPage.ListViewJournals.SelectedItem;
                if (selectedItem != null)
                {
                    _ = new MessageDialog(library.ItemDetails(selectedItem.Guid)).ShowAsync();
                    return;
                }
            }
            if (rbtnRentedItems.IsChecked == true)
            {
                var selectedItem = (LibraryItem)listViewRentedItems.SelectedItem;
                if (selectedItem != null)
                {
                    _ = new MessageDialog(library.ItemDetails(selectedItem.Guid)).ShowAsync();
                    return;
                }
            }
            _ = new MessageDialog("You need to select an item from the list!").ShowAsync();
        }
        private void btnApply_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                mngc.ChangeUsername(customer, txtBoxUsername.Text);
                mngc.ChangePassword(customer, txtBoxPassword.Text);
            }
            catch (InvalidInputException ex)
            {
                _ = new MessageDialog(ex.Message).ShowAsync();
            }
        }
        private void rbtnRentedItems_Checked(object sender, RoutedEventArgs e)
        {
            listViewInbox.Visibility = Visibility.Collapsed;
            listViewRentedItems.Visibility = Visibility.Visible;
            if (listViewRentedItems.Items.Count > 0)
            {
                listViewRentedItems.Items.Clear();

            }
            foreach (var item in customer.GetRentedItems.Values)
            {
                listViewRentedItems.Items.Add(item);
            }
        }
        private void rbtnInbox_Checked(object sender, RoutedEventArgs e)
        {
            listViewRentedItems.Visibility = Visibility.Collapsed;
            listViewInbox.Visibility = Visibility.Visible;
            if (listViewInbox.Items.Count > 0)
            {
                listViewInbox.Items.Clear();
            }
            foreach (var msg in customer.GetMessages)
            {
                listViewInbox.Items.Add(msg);
            }
        }

        private void listViewInbox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Logic.Message selected = (Logic.Message)listViewInbox.SelectedItem;
            if (selected != null)
            {
                string msg = "";
                msg += $"Title:\n" +
                    $"{selected.Title}\n" +
                    $"Body:\n" +
                    $"{selected.Body}";
                MessageDialog messageDialog = new MessageDialog(msg);
                messageDialog.Commands.Add(new UICommand("Delete Message", (command) =>
                {
                    mngc.RemoveMessage(customer, selected);
                    _ = new MessageDialog("The selected message has been deleted!").ShowAsync();
                    rbtnInbox.IsChecked= false;
                    rbtnInbox.IsChecked = true;
                }));
                messageDialog.Commands.Add(new UICommand("Close", (command) =>
                {
                    rbtnInbox.IsChecked = false;
                    rbtnInbox.IsChecked = true;
                }));
                _ = messageDialog.ShowAsync();
            }
        }
    }
}
