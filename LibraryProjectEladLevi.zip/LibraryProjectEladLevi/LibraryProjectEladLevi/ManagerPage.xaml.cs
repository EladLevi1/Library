﻿using Logic;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Reflection.Metadata.Ecma335;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Text.RegularExpressions;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace LibraryProjectEladLevi
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class ManagerPage : Page
    {
        private bool isAdd;
        private Library library;
        private ManageCustomers mngc;
        public ManagerPage()
        {
            this.InitializeComponent();
            foreach (Genre genre in (Genre[])Enum.GetValues(typeof(Genre)))
            {
                cmbxListGenreBook.Items.Add(genre);
                cmbxListGenreJournal.Items.Add(genre);
            }
        }
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            base.OnNavigatedTo(e);
            var param = e.Parameter as ParamToPass;
            if (param != null)
            {
                library = param.Library;
                mngc = param.ManageCustomers;
            }
            rbtnBooks.IsChecked = true;
        }
        private void rbtnBooks_Checked(object sender, RoutedEventArgs e)
        {
            var paramss = new ParamToPass { Mode = Mode.Manager, Library = library };
            frameLists.Navigate(typeof(BooksListPage), paramss);
            CleanChecks();
        }
        private void rbtnJournal_Checked(object sender, RoutedEventArgs e)
        {
            var paramss = new ParamToPass { Mode = Mode.Manager, Library = library };
            frameLists.Navigate(typeof(JournalsListPage), paramss);
            CleanChecks();
        }
        private void RefreshAll()
        {
            if (rbtnBooks.IsChecked == true)
            {
                rbtnBooks.IsChecked = false;
                rbtnBooks.IsChecked = true;
            }
            if (rbtnJournal.IsChecked == true)
            {
                rbtnJournal.IsChecked = false;
                rbtnJournal.IsChecked = true;
            }
            btnClearBook_Click(null, null);
            btnClearJournal_Click(null, null);
            btnDiscountClear_Click(null, null);
        }
        private void CleanChecks()
        {
            if (stackPanelBook != null)
                stackPanelBook.Visibility= Visibility.Collapsed;
            if (stackPanelJournal != null)
                stackPanelJournal.Visibility= Visibility.Collapsed;
            if (listViewCustomers != null)
                listViewCustomers.Visibility= Visibility.Collapsed;
            if (stackPanelDiscount != null)
                stackPanelDiscount.Visibility= Visibility.Collapsed;
        }
        private Genre GetGenres()
        {
            List<Genre> selectedGenres = new List<Genre>();
            Genre g = 0;
            if (rbtnBooks.IsChecked == true)
            {
                foreach (object item in cmbxListGenreBook.SelectedItems)
                    selectedGenres.Add((Genre)item);
                foreach (Genre item in selectedGenres)
                    g |= item;
            }
            else
            {
                foreach (object item in cmbxListGenreJournal.SelectedItems)
                    selectedGenres.Add((Genre)item);
                foreach (Genre item in selectedGenres)
                    g |= item;
            }
            return g;
        }
        private void btnApplyBook_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string title = library.CheckIfTitleValid(txtBoxTitleBook.Text);
                double price = library.CheckIfPriceIsValid(txtBoxPriceBook.Text);
                string author = library.CheckIfAuthorIsValid(txtBoxAuthorBook.Text);
                string description = library.CheckIfDescriptionIsValid(txtBoxDescriptionBook.Text);
                string company = library.CheckIfCompanyIsValid(txtBoxCompanyBook.Text);
                Genre genre = library.CheckIfGenreIsValid(GetGenres());
                DateTime time;
                if (!calendarDatePickerBook.Date.HasValue)
                    time = DateTime.Today;
                else
                    time = calendarDatePickerBook.Date.Value.DateTime;
                time = library.CheckIfDateTimeCreatedIsValid(time);
                if (isAdd == true)
                {
                    Book book = new Book(title, price, author, description, company, genre, time);
                    library.AddItem(book);
                }
                else
                {
                    BooksListPage booksListPage = (BooksListPage)frameLists.Content;
                    Book selectedItem = (Book)booksListPage.ListViewBooks.SelectedItem;
                    library.EditItemTitle(selectedItem.Guid, title);
                    library.EditItemPrice(selectedItem.Guid, price.ToString());
                    library.EditItemAuthor(selectedItem.Guid, author);
                    library.EditItemDescription(selectedItem.Guid, description);
                    library.EditItemCompany(selectedItem.Guid, company);
                    library.EditItemGenre(selectedItem.Guid, genre);
                    library.EditItemDateTimeCreated(selectedItem.Guid, time);
                }
                RefreshAll();
            }
            catch (InvalidInputException ex)
            {
                _ = new MessageDialog(ex.Message).ShowAsync();
            }
        }
        private void btnApplyJournal_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string title = library.CheckIfTitleValid(txtBoxTitleJournal.Text);
                double price = library.CheckIfPriceIsValid(txtBoxPriceJournal.Text);
                string description = library.CheckIfDescriptionIsValid(txtBoxDescriptionJournal.Text);
                string company = library.CheckIfCompanyIsValid(txtBoxCompanyJournal.Text);
                Genre genre = library.CheckIfGenreIsValid(GetGenres());
                DateTime time = DateTime.Today;
                if (calendarDatePickerJournal.Date.HasValue)
                    time = library.CheckIfDateTimeCreatedIsValid(calendarDatePickerJournal.Date.Value.DateTime);
                if (isAdd == true)
                {
                    Journal journal = new Journal(title, price, description, company, genre, time);
                    library.AddItem(journal);
                }
                else
                {
                    JournalsListPage journalsListPage = (JournalsListPage)frameLists.Content;
                    Journal selectedItem = (Journal)journalsListPage.ListViewJournals.SelectedItem;
                    library.EditItemTitle(selectedItem.Guid, title);
                    library.EditItemPrice(selectedItem.Guid, price.ToString());
                    library.EditItemDescription(selectedItem.Guid, description);
                    library.EditItemCompany(selectedItem.Guid, company);
                    library.EditItemGenre(selectedItem.Guid, genre);
                    library.EditItemDateTimeCreated(selectedItem.Guid, time);
                }
                RefreshAll();
            }
            catch (InvalidInputException ex)
            {
                _ = new MessageDialog(ex.Message).ShowAsync();
            }
        }
        private void btnClearBook_Click(object sender, RoutedEventArgs e)
        {
            if (txtBoxTitleBook != null)
                txtBoxTitleBook.Text = "";
            if (txtBoxPriceBook != null)
                txtBoxPriceBook.Text = "";
            if (txtBoxAuthorBook != null)
                txtBoxAuthorBook.Text = "";
            if (txtBoxDescriptionBook != null)
                txtBoxDescriptionBook.Text = "";
            if (txtBoxCompanyBook != null)
                txtBoxCompanyBook.Text = "";
            if (cmbxGenreBook!= null)
                cmbxListGenreBook.SelectedItem = null;
            if (calendarDatePickerBook!= null)
                calendarDatePickerBook.Date = null;
        }
        private void btnClearJournal_Click(object sender, RoutedEventArgs e)
        {
            if (txtBoxTitleJournal != null)
                txtBoxTitleJournal.Text = "";
            if (txtBoxPriceJournal != null)
                txtBoxPriceJournal.Text = "";
            if (txtBoxDescriptionJournal != null)
                txtBoxDescriptionJournal.Text = "";
            if (txtBoxCompanyJournal != null)
                txtBoxCompanyJournal.Text = "";
            if (cmbxGenreJournal != null)
                cmbxListGenreJournal.SelectedItem = null;
            if (calendarDatePickerJournal != null)
                calendarDatePickerJournal.Date = null;
        }
        private async void btnRemove_Click(object sender, RoutedEventArgs e)
        {
            CleanChecks();
            if (rbtnBooks.IsChecked == true)
            {
                BooksListPage booksListPage = (BooksListPage)frameLists.Content;
                Book selectedItem = (Book)booksListPage.ListViewBooks.SelectedItem;
                if (selectedItem != null)
                {
                    if (selectedItem.IsRented == IsRented.No)
                    {
                        MessageDialog messageDialog = new MessageDialog("Sure you want to remove the item from the library?");
                        messageDialog.Commands.Add(new UICommand("Yes", (command) => { library.RemoveItem(selectedItem.Guid); RefreshAll(); }));
                        messageDialog.Commands.Add(new UICommand("No"));
                        await messageDialog.ShowAsync();
                    }
                    else
                    {
                        _ = new MessageDialog("You can't remove a rented item!").ShowAsync();
                    }
                }
                else
                {
                    _ = new MessageDialog("You need to select an item from the list!").ShowAsync();
                }
            }
            if (rbtnJournal.IsChecked == true)
            {
                JournalsListPage journalsListPage = (JournalsListPage)frameLists.Content;
                Journal selectedItem = (Journal)journalsListPage.ListViewJournals.SelectedItem;
                if (selectedItem != null)
                {
                    if (selectedItem.IsRented == IsRented.No)
                    {
                        MessageDialog messageDialog = new MessageDialog("Sure you want to remove the item from the library?");
                        messageDialog.Commands.Add(new UICommand("Yes", (command) => { library.RemoveItem(selectedItem.Guid); RefreshAll(); }));
                        messageDialog.Commands.Add(new UICommand("No"));
                        await messageDialog.ShowAsync();
                    }
                    else
                    {
                        _ = new MessageDialog("You need to select an item from the list!").ShowAsync();
                    }
                }
                else
                {
                    _ = new MessageDialog("You need to select an item from the list!").ShowAsync();
                }
            }
        }
        private void btnEdit_Click(object sender, RoutedEventArgs e)
        {
            CleanChecks();
            isAdd = false;
            if (rbtnBooks.IsChecked == true)
            {
                BooksListPage booksListPage = (BooksListPage)frameLists.Content;
                Book selectedItem = (Book)booksListPage.ListViewBooks.SelectedItem;
                if (selectedItem != null)
                {
                    if (selectedItem.IsRented == IsRented.No)
                    {
                        stackPanelBook.Visibility = Visibility.Visible;
                        txtBoxTitleBook.Text = selectedItem.Title;
                        txtBoxPriceBook.Text = selectedItem.Price.ToString();
                        txtBoxAuthorBook.Text = selectedItem.Author;
                        txtBoxDescriptionBook.Text = selectedItem.Description;
                        txtBoxCompanyBook.Text = selectedItem.Company;
                        calendarDatePickerBook.Date = selectedItem.DateTimeCreated;
                        for (int i = 0; i < cmbxListGenreBook.Items.Count; i++)
                        {
                            if (selectedItem.Genre.HasFlag((Genre)cmbxListGenreBook.Items[i]))
                            {
                                cmbxListGenreBook.SelectedItems.Add(cmbxListGenreBook.Items[i]);
                            }
                        }
                    }
                    else
                    {
                        _ = new MessageDialog("You can't edit a rented item!").ShowAsync();
                    }
                }
                else
                {
                    _ = new MessageDialog("You need to select an item from the list!").ShowAsync();
                }
            }
            if (rbtnJournal.IsChecked == true)
            {
                JournalsListPage journalsListPage = (JournalsListPage)frameLists.Content;
                Journal selectedItem = (Journal)journalsListPage.ListViewJournals.SelectedItem;
                if (selectedItem != null)
                {
                    if (selectedItem.IsRented == IsRented.No)
                    {
                        stackPanelJournal.Visibility = Visibility.Visible;
                        txtBoxTitleJournal.Text = selectedItem.Title;
                        txtBoxPriceJournal.Text = selectedItem.Price.ToString();
                        txtBoxDescriptionJournal.Text = selectedItem.Description;
                        txtBoxCompanyJournal.Text = selectedItem.Company;
                        calendarDatePickerJournal.Date = selectedItem.DateTimeCreated;
                        for (int i = 0; i < cmbxListGenreJournal.Items.Count; i++)
                        {
                            if (selectedItem.Genre.HasFlag((Genre)cmbxListGenreJournal.Items[i]))
                            {
                                cmbxListGenreJournal.SelectedItems.Add(cmbxListGenreJournal.Items[i]);
                            }
                        }
                    }
                    else
                    {
                        _ = new MessageDialog("You can't edit a rented item!").ShowAsync();
                    }
                }
                else
                {
                    _ = new MessageDialog("You need to select an item from the list!").ShowAsync();
                }
            }
        }
        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            CleanChecks();
            isAdd = true;
            if (rbtnBooks.IsChecked == true)
            {
                btnClearBook_Click(null, null);
                stackPanelJournal.Visibility = Visibility.Collapsed;
                stackPanelBook.Visibility = Visibility.Visible;
            }
            if (rbtnJournal.IsChecked == true)
            {
                btnClearJournal_Click(null, null);
                stackPanelBook.Visibility = Visibility.Collapsed;
                stackPanelJournal.Visibility = Visibility.Visible;
            }
        }
        private void btnBackToMain_Click(object sender, RoutedEventArgs e)
        {
            var paramms = new ParamToPass { Library = library, ManageCustomers = mngc };
            Frame.Navigate(typeof(MainPage) ,paramms);
        }
        private void btnItemInfo_Click(object sender, RoutedEventArgs e)
        {
            CleanChecks();
            if (rbtnBooks.IsChecked == true)
            {
                BooksListPage booksListPage = (BooksListPage)frameLists.Content;
                Book selectedItem = (Book)booksListPage.ListViewBooks.SelectedItem;
                if (selectedItem != null)
                {
                    _ = new MessageDialog(library.ItemDetails(selectedItem.Guid)).ShowAsync();
                }
                else
                {
                    _ = new MessageDialog("You need to select an item from the list!").ShowAsync();
                }
            }
            if (rbtnJournal.IsChecked == true)
            {
                JournalsListPage journalsListPage = (JournalsListPage)frameLists.Content;
                Journal selectedItem = (Journal)journalsListPage.ListViewJournals.SelectedItem;
                if (selectedItem != null)
                {
                    _ = new MessageDialog(library.ItemDetails(selectedItem.Guid)).ShowAsync();
                }
                else
                {
                    _ = new MessageDialog("You need to select an item from the list!").ShowAsync();
                }
            }
        }
        private void btnDailyStatus_Click(object sender, RoutedEventArgs e)
        {
            CleanChecks();
            string books = "Books:\n";
            int booksCounter = 0;
            string rentedBooks = "Rented Books:\n";
            int rentedBooksCounter = 0;
            string journals = "Journals:\n";
            int journalsCounter = 0;
            string rentedJournals = "Rented Journals:\n";
            int rentedJournalsCounter = 0;
            string DailyInfo;
            foreach (var item in library.GetDic.Values)
            {
                if (item.GetType() == typeof(Book))
                {
                    if (item.IsRented == IsRented.Yes)
                    {
                        if (item.FinalRentTime > DateTime.Now)
                        {
                            rentedBooks += $"{item.Title}, Rented Since: {item.StartingRentTime:d}, Final rent date: {item.FinalRentTime:d}\n";
                        }
                        else
                        {
                            rentedBooks += $"{item.Title}, Rented Since: {item.StartingRentTime:d}, Missed the return date by {item.FinalRentTime - DateTime.Now} days.\n";
                        }
                        rentedBooksCounter++;
                    }
                    else
                    {
                        books += item.Title + "\n";
                        booksCounter++;
                    }
                }
                if (item.GetType() == typeof(Journal))
                {
                    if (item.IsRented == IsRented.Yes)
                    {
                        if (item.FinalRentTime > DateTime.Now)
                        {
                            rentedJournals += $"{item.Title}, Rented Since: {item.StartingRentTime:d}, Final rent date: {item.FinalRentTime:d}\n";
                        }
                        else
                        {
                            rentedJournals += $"{item.Title}, Rented Since: {item.StartingRentTime:d}, Missed the return date by {item.FinalRentTime - DateTime.Now} days.\n";
                        }
                        rentedJournalsCounter++;
                    }
                    else
                    {
                        journals+= item.Title + "\n";
                        journalsCounter++;
                    }
                }
            }
            DailyInfo= books + journals + rentedBooks + rentedJournals;
            if (booksCounter + journalsCounter + rentedBooksCounter + rentedJournalsCounter > 0)
                _ = new MessageDialog(DailyInfo).ShowAsync();
            else
                _ = new MessageDialog("There are no items!").ShowAsync();
        }
        private void btnCustomers_Click(object sender, RoutedEventArgs e)
        {
            CleanChecks();
            listViewCustomers.Items.Clear();
            listViewCustomers.Visibility = Visibility.Visible;
            foreach (Customer cust in mngc.GetCustomers)
            {
                listViewCustomers.Items.Add(cust);
            }
        }
        private async void listViewCustomers_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Customer cust = listViewCustomers.SelectedItem as Customer;
            if (cust != null)
            {
                MessageDialog messageDialog = new MessageDialog(cust.ToString());
                messageDialog.Commands.Add(new UICommand("Send Message", async (command) =>
                {
                    var dialog = new ContentDialog();
                    dialog.Title = "Send Message to Customer";
                    dialog.Content = new StackPanel
                    {
                        Children =
                        {
                            new TextBlock
                            {
                                Text = "Message Title:"
                            },
                            new TextBox
                            {
                                Name = "TitleTextBox",
                                Text = ""
                            },
                            new TextBlock
                            {
                                Text = "Message Body:"
                            },
                            new TextBox
                            {
                                Name = "BodyTextBox",
                                Text = ""
                            }
                        }
                    };
                    dialog.PrimaryButtonText = "Send Message";
                    dialog.SecondaryButtonText = "Cancel";
                    var result = await dialog.ShowAsync();
                    if (result == ContentDialogResult.Primary)
                    {
                        var titleTextBox = GetTextBox(dialog, "TitleTextBox");
                        var bodyTextBox = GetTextBox(dialog, "BodyTextBox");
                        Message msg = new Message();
                        msg.Title= titleTextBox.Text;
                        msg.Body = bodyTextBox.Text;
                        mngc.SendMessage(cust, msg);
                        _ = new MessageDialog("The message has been sent!").ShowAsync();
                        listViewCustomers.Visibility = Visibility.Collapsed;
                    }
                }));
                messageDialog.Commands.Add(new UICommand("Remove Customer", (command) =>
                {
                    if (cust.GetRentedItems.Count == 0)
                    {
                        mngc.RemoveCustomer(cust);
                        _ = new MessageDialog("You removed the customer successfully!").ShowAsync();
                        listViewCustomers.Visibility= Visibility.Collapsed;
                    }
                    else
                    {
                        _ = new MessageDialog("You cant remove a customer with rented items!").ShowAsync();
                    }
                }));
                messageDialog.Commands.Add(new UICommand("Close", (command) =>
                {
                    btnCustomers_Click(null, null);
                }));
                await messageDialog.ShowAsync();
            }
        }
        private TextBox GetTextBox(ContentDialog dialog, string name)
        {
            var panel = dialog.Content as Panel;
            if (panel == null)
            {
                return null;
            }
            for (int i = 0; i < panel.Children.Count; i++)
            {
                var child = panel.Children[i];
                var textBox = child as TextBox;
                if (textBox != null && textBox.Name == name)
                {
                    return textBox;
                }
            }
            return null;
        }
        private void btnGiveDiscount_Click(object sender, RoutedEventArgs e)
        {
            CleanChecks();
            stackPanelDiscount.Visibility = Visibility.Visible;
            rbtnDiscountTitle.IsChecked = true;
        }
        private void btnDiscountApply_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string txt = library.CheckIfDescriptionIsValid(txtBoxDiscountInputString.Text).ToLower();
                double dis = library.CheckIfDiscountIsValid(txtBoxDiscountInputDouble.Text);
                DateTime time;
                if (!dateOfFinishDiscount.Date.HasValue)
                    time = DateTime.Today;
                else
                    time = dateOfFinishDiscount.Date.Value.DateTime;
                time = library.CheckIfDiscountFinalDateIsValid(time);
                dis /= 100;
                int counterDis = 0;
                foreach (var item in library.GetDic.Values)
                {
                    if (item.IsRented == IsRented.No)
                    {
                        if (dis > item.Discount)
                        {
                            if (rbtnDiscountTitle.IsChecked == true)
                            {
                                if (item.Title.ToLower() == txt)
                                {
                                    library.EditItemPrice(item.Guid, (item.OriginalPrice - (item.OriginalPrice * dis)).ToString());
                                    item.Discount = dis;
                                    item.FinalDiscount = time;
                                    counterDis++;
                                }
                            }
                            else if (rbtnDiscountAuthor.IsChecked == true)
                            {
                                if (item is IAuthor)
                                {
                                    Book i = (Book)item;
                                    if (i.Author.ToLower() == txt)
                                    {
                                        library.EditItemPrice(item.Guid, (item.OriginalPrice - (item.OriginalPrice * dis)).ToString());
                                        item.Discount = dis;
                                        item.FinalDiscount = time;
                                        counterDis++;
                                    }
                                }
                            }
                            else if (rbtnDiscountCompany.IsChecked == true)
                            {
                                if (item.Company.ToLower() == txt)
                                {
                                    library.EditItemPrice(item.Guid, (item.OriginalPrice - (item.OriginalPrice * dis)).ToString());
                                    item.Discount = dis;
                                    item.FinalDiscount = time;
                                    counterDis++;
                                }
                            }
                            else if (rbtnDiscountGenre.IsChecked == true)
                            {
                                List<string> g = new List<string>();
                                foreach (Genre genre in (Genre[])Enum.GetValues(typeof(Genre)))
                                {
                                    if (item.Genre.HasFlag(genre))
                                    {
                                        g.Add(genre.ToString().ToLower());
                                    }
                                }
                                if (g.Contains(txt))
                                {
                                    library.EditItemPrice(item.Guid, (item.OriginalPrice - (item.OriginalPrice * dis)).ToString());
                                    item.Discount = dis;
                                    item.FinalDiscount = time;
                                    counterDis++;
                                }
                            }
                        }
                    }
                }
                if (counterDis == 0)
                    _ = new MessageDialog("No items was found or the items you are trying to\napply discount already have higher discount option!\nPlease try again!").ShowAsync();
                else
                {
                    _ = new MessageDialog($"{counterDis} items was found and recieved a new discount price!").ShowAsync();
                    RefreshAll();
                }
            }
            catch (InvalidInputException ex)
            {
                _ = new MessageDialog(ex.Message).ShowAsync();
            }
        }
        private void btnDiscountClear_Click(object sender, RoutedEventArgs e)
        {
            if (txtBoxDiscountInputString != null)
                txtBoxDiscountInputString.Text = "";
            if (txtBoxDiscountInputDouble != null)
                txtBoxDiscountInputDouble.Text = "";
            if (dateOfFinishDiscount != null)
                dateOfFinishDiscount.Date = null;
        }
    }
}
