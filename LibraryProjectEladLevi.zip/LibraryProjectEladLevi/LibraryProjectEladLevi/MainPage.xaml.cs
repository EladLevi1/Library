﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using Logic;
using System.Text.RegularExpressions;
using System.ServiceModel.Channels;
using Windows.UI.Popups;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace LibraryProjectEladLevi
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        private Library library;
        private ManageCustomers Mngc;
        public MainPage()
        {
            this.InitializeComponent();
        }
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            base.OnNavigatedTo(e);
            if (e.Parameter is ParamToPass)
            {
                var param = e.Parameter as ParamToPass;
                if (param != null)
                {
                    library = param.Library;
                    Mngc = param.ManageCustomers;
                }
            }
            else
            {
                library = new Library();
                Mngc = new ManageCustomers();
            }
        }
        private void btnCustomer_Click(object sender, RoutedEventArgs e)
        {
            btnCustomer.Visibility = Visibility.Collapsed;
            txtBoxUsername.Visibility = Visibility.Visible;
            txtBoxPassword.Visibility = Visibility.Visible;
            btnRegister.Visibility = Visibility.Visible;
            btnLogin.Visibility = Visibility.Visible;
        }
        private void btnManager_Click(object sender, RoutedEventArgs e)
        {
            var paramss = new ParamToPass { ManageCustomers = Mngc, Library = library };
            Frame.Navigate(typeof(ManagerPage), paramss);
        }

        private void btnRegister_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Mngc.Register(txtBoxUsername.Text, txtBoxPassword.Password);
                btnLogin_Click(null, null);
            }
            catch (InvalidInputException ex)
            {
                _ = new MessageDialog(ex.Message).ShowAsync();
            }
        }

        private void btnLogin_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Customer cust1 = Mngc.Login(txtBoxUsername.Text, txtBoxPassword.Password);
                var paramss = new ParamToPass { ManageCustomers = Mngc ,Customer = cust1, Library = library };
                Frame.Navigate(typeof(CustomerPage), paramss);
            }
            catch (InvalidInputException ex)
            {
                _ = new MessageDialog(ex.Message).ShowAsync();
            }
        }
    }
    public class ParamToPass
    {
        public Mode Mode { get; set; }
        public Library Library { get; set; }
        public Customer Customer { get; set; }
        public ManageCustomers ManageCustomers { get; set; }
    }
    public enum Mode { Manager, Customer }
}
